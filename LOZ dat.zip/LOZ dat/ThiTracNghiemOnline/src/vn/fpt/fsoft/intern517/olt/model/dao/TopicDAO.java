package vn.fpt.fsoft.intern517.olt.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import java.sql.SQLException;

import vn.fpt.fsoft.intern517.olt.model.bean.Topic;

public class TopicDAO extends BaseDAO {
	
	public ArrayList<Topic> getListTopic() {
		String sqlgetListTopic = "SELECT topicID , topicName FROM [TOPIC]";
		ResultSet rs = null;
		
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlgetListTopic);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		ArrayList<Topic> list = new ArrayList<Topic>();
		try {
			while (rs.next()) {
				Topic topic = new Topic();
				topic.setTopicID(rs.getString("topicID"));
				topic.setTopicName(rs.getString("topicName"));
				list.add(topic);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
