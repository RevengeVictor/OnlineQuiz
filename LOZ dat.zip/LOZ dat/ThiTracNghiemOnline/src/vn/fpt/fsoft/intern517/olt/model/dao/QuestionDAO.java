package vn.fpt.fsoft.intern517.olt.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.Question;

public class QuestionDAO extends BaseDAO {
	
	public ArrayList<Question> getListQuestion(){
		String sqlgetListQuestion = "SELECT * FROM QUESTION";
		ResultSet rs = null;
		
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlgetListQuestion);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Question> list = new ArrayList<Question>();
		try {
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionID(rs.getString("questionID"));
				question.setQuestionName(rs.getString("questionName"));
				question.setTopicID(rs.getString("topicID"));
				question.setAnswer(rs.getString("answer"));
				question.setMaxAnswer(rs.getString("maxAnswer"));
				list.add(question);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
	public ArrayList<Question> getListQuestion(String topicID){
		String sqlgetListQuestion = "SELECT * FROM QUESTION Where topicID = "+topicID;
		ResultSet rs = null;
		
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlgetListQuestion);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Question> list = new ArrayList<Question>();
		try {
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionID(rs.getString("questionID"));
				question.setQuestionName(rs.getString("questionName"));
				question.setTopicID(rs.getString("topicID"));
				question.setAnswer(rs.getString("answer"));
				question.setMaxAnswer(rs.getString("maxAnswer"));
				list.add(question);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
}
