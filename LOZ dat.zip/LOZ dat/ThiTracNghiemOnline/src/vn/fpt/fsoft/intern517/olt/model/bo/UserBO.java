package vn.fpt.fsoft.intern517.olt.model.bo;

import vn.fpt.fsoft.intern517.olt.model.dao.UserDAO;

public class UserBO {
	static UserDAO userDAO = new UserDAO();
	
	public boolean checkLogin(String userName, String password){
		return userDAO.checkLogin(userName, password );
	}


}
