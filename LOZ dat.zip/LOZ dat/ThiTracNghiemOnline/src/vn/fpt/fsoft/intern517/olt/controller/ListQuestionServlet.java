package vn.fpt.fsoft.intern517.olt.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vn.fpt.fsoft.intern517.olt.model.bean.Question;
import vn.fpt.fsoft.intern517.olt.model.bo.QuestionBO;

/**
 * Servlet implementation class ListQuestionServlet
 */
public class ListQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		if (session.getAttribute("userName") == null) {
			response.sendRedirect("LoginServlet");
			return;
		}
		
		ArrayList<Question> listQuestion;
		QuestionBO questionBO = new QuestionBO();
		String topicID=request.getParameter("topicID");
		
		if(topicID==null || topicID.length()==0){
			listQuestion = questionBO.getListQuestion();
		} else {
			listQuestion = questionBO.getListQuestion(topicID);
		}
		request.setAttribute("listQuestion", listQuestion);
		
		RequestDispatcher rd = request.getRequestDispatcher("Quiz.jsp");
		rd.forward(request, response);
	}

}
