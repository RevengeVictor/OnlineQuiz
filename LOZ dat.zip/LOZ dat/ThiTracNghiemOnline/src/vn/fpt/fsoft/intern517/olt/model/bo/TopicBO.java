package vn.fpt.fsoft.intern517.olt.model.bo;

import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.Topic;
import vn.fpt.fsoft.intern517.olt.model.dao.TopicDAO;

public class TopicBO {
	TopicDAO topicDAO = new TopicDAO();
	
	public ArrayList<Topic> getListTopic(){
		return topicDAO.getListTopic();
		
	}
}
