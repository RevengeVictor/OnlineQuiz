  package vn.fpt.fsoft.intern517.olt.model.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserDAO extends BaseDAO {
	
	public boolean checkLogin(String userName, String password) {
		String sqlCheckLogin = "SELECT userName FROM [USER] WHERE userName = ? and password = ?";
		ResultSet rs = null;
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlCheckLogin);
			restmt.setString(1, userName);
			restmt.setString(2, password);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			if (rs.isBeforeFirst()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}
	
}
