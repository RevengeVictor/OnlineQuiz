package vn.fpt.fsoft.intern517.olt.model.bean;

public class Question {
	private String questionID;
	private String questionName;
	private String topicID;
	private String answer;
	private String maxAnswer;
	public String getQuestionID() {
		return questionID;
	}
	public void setQuestionID(String questionID) {
		this.questionID = questionID;
	}
	public String getQuestionName() {
		return questionName;
	}
	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}
	public String getTopicID() {
		return topicID;
	}
	public void setTopicID(String topicID) {
		this.topicID = topicID;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getMaxAnswer() {
		return maxAnswer;
	}
	public void setMaxAnswer(String maxAnswer) {
		this.maxAnswer = maxAnswer;
	}
	
	
}
