package vn.fpt.fsoft.intern517.olt.model.bo;

import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.Question;
import vn.fpt.fsoft.intern517.olt.model.dao.QuestionDAO;

public class QuestionBO {
	QuestionDAO questionDAO = new QuestionDAO();
	
	public ArrayList<Question> getListQuestion(){
		return questionDAO.getListQuestion();
	}
	
	public ArrayList<Question> getListQuestion(String topicID) {
		return questionDAO.getListQuestion(topicID);
	}
	
}
