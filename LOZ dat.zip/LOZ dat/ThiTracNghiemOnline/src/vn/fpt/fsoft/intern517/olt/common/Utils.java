package vn.fpt.fsoft.intern517.olt.common;

public class Utils {
	public static String gender(String sex) {
		if("0".equals(sex)){
			return "Nữ";
		}
		return "Nam";
	}
}