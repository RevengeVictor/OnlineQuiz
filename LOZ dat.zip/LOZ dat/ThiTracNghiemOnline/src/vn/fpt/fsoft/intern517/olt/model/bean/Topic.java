package vn.fpt.fsoft.intern517.olt.model.bean;

public class Topic {
	private String topicName;
	private String topicID;
	
	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public String getTopicID() {
		return topicID;
	}

	public void setTopicID(String topicID) {
		this.topicID = topicID;
	}
	
	
}
