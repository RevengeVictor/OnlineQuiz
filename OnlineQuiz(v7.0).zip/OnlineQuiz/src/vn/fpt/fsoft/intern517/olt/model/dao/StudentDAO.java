package vn.fpt.fsoft.intern517.olt.model.dao;

/**
 * StudentDAO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 14, 2017        Nguyen Cong Huong          	Create
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDAO extends BaseDAO {
	/*
	 * Ham tra ve ten hoc sinh theo username
	 */
	public String getStudentName(String userName) {
		String sqlStudentName = "SELECT fullName FROM [STUDENT] WHERE studentID = ?";
		ResultSet rs = null;
		
		//Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlStudentName);
			restmt.setString(1, userName);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Lay ket qua truy van
		String studentName=null;
		try {
			while (rs.next()) {
				studentName = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return studentName;
	}
}
