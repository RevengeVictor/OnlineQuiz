package vn.fpt.fsoft.intern517.olt.common;

/**
 * Utils.java
 * 
 * Version 1.0
 * 
 * Date: June 13, 2017
 * 
 * Copyright
 * 
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- June
 * 13, 2017 Nguyen Cong Huong Create
 */

public class Utils {
	/**
	 * Ham tra ve gioi tinh: 1=Nam, 0=Nu
	 * 
	 * @param val
	 * @return String
	 */
	public static String gender(String sex) {
		if ("0".equals(sex)) {
			return "Nữ";
		}
		return "Nam";
	}

	/*
	 * Ham tra ve: true = la so, false = la chuoi
	 */
	public static boolean checkNumber(String cloneNumber) {

		if (Character.isDigit(cloneNumber.charAt(0))) {
			return true;
		}
		return false;
	}

	/*
	 * Ham tra ve ten topic clone
	 */
	public static String newTopicName(String topicName, String cloneNumber,
			String check) {
		String newTopicName = "";

		if (check.equals("true")) {
			newTopicName = topicName + " (Thi lần "
					+ (Integer.parseInt(cloneNumber.substring(6)) + 1) + ")";
		} else if (check.equals("false")){
			newTopicName = topicName.substring(0,
					topicName.indexOf("(Thi lần ")).trim()
					+ " (Thi lần "
					+ (Integer.parseInt(cloneNumber.substring(6)) + 1) + ")";
		}

		return newTopicName;
	}

	/*
	 * Ham tang so trong chuoi len 1
	 */
	public static String incString(String cloneNumber) {
		String newString = "" + cloneNumber.substring(0, 6)
				+ (Integer.parseInt(cloneNumber.substring(6)) + 1);

		return newString;
	}
}
