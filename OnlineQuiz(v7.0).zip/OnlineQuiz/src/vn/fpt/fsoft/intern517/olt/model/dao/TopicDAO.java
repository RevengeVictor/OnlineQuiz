package vn.fpt.fsoft.intern517.olt.model.dao;

/**
 * TopicDAO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 15, 2017        Nguyen Cong Huong          	Create
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.common.Utils;
import vn.fpt.fsoft.intern517.olt.model.bean.Topic;

public class TopicDAO extends BaseDAO {
	/*
	 * Tra ve mot danh sach: ma topic va ten topic
	 */
	public ArrayList<Topic> getListTopic() {
		String sqlListTopic = "select topicID, topicName from [TOPIC]";
		ResultSet rs = null;

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListTopic);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Lay ket qua truy van
		ArrayList<Topic> listTopic = new ArrayList<Topic>();
		Topic topic;
		try {
			while (rs.next()) {
				topic = new Topic();
				topic.setTopicID(rs.getInt(1));
				topic.setTopicName(rs.getString(2));
				listTopic.add(topic);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listTopic;
	}

	/*
	 * Xoa mot topic theo topicID
	 */
	public void deleteTopic(String topicID) {
		String sqlListTopic = "DELETE FROM [TOPIC] WHERE topicID = ?";

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListTopic);
			restmt.setInt(1, Integer.parseInt(topicID));
			restmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Ham lay so cloneNumber
	 */
	public String cloneNumber(String topicID) {
		String sqlCloneNumber = "SELECT cloneNumber FROM [TOPIC] WHERE topicID = ?";
		ResultSet rs = null;

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlCloneNumber);
			restmt.setInt(1, Integer.parseInt(topicID));
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String cloneNumber = "";

		try {
			while (rs.next()) {
				cloneNumber = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cloneNumber;
	}

	/*
	 * Ham tra ve topicID cuoi cung theo topicName
	 */
	public int getTopicID(String topicName) {
		String sqlTopicID = "SELECT topicID FROM [TOPIC] WHERE topicName = ?";
		ResultSet rs = null;

		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection.prepareStatement(sqlTopicID);
			restmt.setString(1, topicName);
			rs = restmt.executeQuery();
			;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		int topic = 0;

		try {
			while (rs.next()) {
				topic = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return topic;
	}

	/*
	 * Ham clone topic
	 */
	public void cloneTopic(String topicID, String topicName) {
		String sqlNewTopic = "INSERT INTO [TOPIC](topicName, cloneNumber) VALUES (?,?)";
		String sqlUdateCloneNumber = "UPDATE [TOPIC] SET cloneNumber = ? WHERE topicID = ?";
		String sqlCloneTopic = "INSERT INTO [QUIZ](quizName, topicID, answer, maxAnswer) SELECT q.quizName, t.topicID, q.answer, q.maxAnswer FROM [QUIZ] as q, [TOPIC] as t WHERE q.topicID = ? AND t.topicID = ?";
		PreparedStatement restmt = null;

		String cloneNumber = cloneNumber(topicID);

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();

			// Them topic moi
			if (Utils.checkNumber(cloneNumber(topicID))) {
				restmt = connection.prepareStatement(sqlNewTopic);
				restmt.setString(1, Utils.newTopicName(topicName,
						cloneNumber(cloneNumber), "false"));
				restmt.setString(2, cloneNumber(topicID));
				restmt.executeUpdate();
			} else {
				restmt = connection.prepareStatement(sqlNewTopic);
				System.out.println("Them: " + topicName + " " + cloneNumber);
				restmt.setString(1,
						Utils.newTopicName(topicName, cloneNumber, "true"));
				restmt.setString(2, topicID);
				restmt.executeUpdate();
			}

			// Cap nhat cloneNumber
			System.out.println("Check number:" + cloneNumber(topicID)+ " "+Utils.checkNumber(cloneNumber(topicID)));
			if (Utils.checkNumber(cloneNumber(topicID))) {
				System.out.println("1");
				restmt = connection.prepareStatement(sqlUdateCloneNumber);
				System.out.println("Cap Nhat clone: " + cloneNumber + " "
						+ cloneNumber(cloneNumber));
				restmt.setString(1, cloneNumber(cloneNumber));
				restmt.setInt(2, Integer.parseInt(cloneNumber));
				restmt.executeUpdate();
			} else {
				System.out.println("2");
				restmt = connection.prepareStatement(sqlUdateCloneNumber);
//				System.out.println("Cap Nhat goc: " + cloneNumber(cloneNumber) + " "
//						+ Integer.parseInt(topicID));
				restmt.setString(1, Utils.incString(cloneNumber(topicID)));
				restmt.setInt(2, Integer.parseInt(topicID));
				restmt.executeUpdate();
			}

			// Clone
			if (Utils.checkNumber(cloneNumber(topicID))) {
				restmt = connection.prepareStatement(sqlCloneTopic);
				restmt.setInt(1, Integer.parseInt(topicID));
				restmt.setInt(2, getTopicID(Utils.newTopicName(topicName,
						cloneNumber, "false")));
				restmt.executeUpdate();
			} else {
				restmt = connection.prepareStatement(sqlCloneTopic);
				restmt.setInt(1, Integer.parseInt(topicID));
				restmt.setInt(2, getTopicID(Utils.newTopicName(topicName,
						cloneNumber, "true")));
				restmt.executeUpdate();
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
