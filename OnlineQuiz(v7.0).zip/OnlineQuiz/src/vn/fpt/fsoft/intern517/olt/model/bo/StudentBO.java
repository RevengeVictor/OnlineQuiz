package vn.fpt.fsoft.intern517.olt.model.bo;
/**
 * StudentBO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 14, 2017        Nguyen Cong Huong          	Create
 */
import vn.fpt.fsoft.intern517.olt.model.dao.StudentDAO;

public class StudentBO {
	StudentDAO studentDAO = new StudentDAO();
	
	public String getStudentName(String userName){
		return studentDAO.getStudentName(userName);
	}
}
