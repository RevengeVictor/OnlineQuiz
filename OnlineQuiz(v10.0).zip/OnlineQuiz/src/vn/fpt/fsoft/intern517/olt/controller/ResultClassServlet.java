package vn.fpt.fsoft.intern517.olt.controller;
/**
 * ResultClassServlet.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 27, 2017        Nguyen Cong Huong          	Create
 */

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vn.fpt.fsoft.intern517.olt.common.Constants;
import vn.fpt.fsoft.intern517.olt.model.bo.ClassBO;

public class ResultClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ResultClassServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		ClassBO classBO = new ClassBO();
		
		// Kiem tra da dang nhap chua
		if (session.getAttribute("userName") == null) {
			response.sendRedirect("LoginServlet");
			return;
		}
		
		// Kiem tra quyen dang nhap
		if (Constants.STUDENT_RIGHTS.equals(session.getAttribute("type"))) {
			response.sendRedirect("WelcomeStudentServlet");
			return;
		}
		
		if("submit".equals(request.getParameter("submitClass"))){
			
		}else if("submit".equals(request.getParameter("submitExcel"))){
			
		}else{
			request.setAttribute("listClass", classBO.getListClass());
			request.setAttribute("selectClass", "1");
			RequestDispatcher rd = request
					.getRequestDispatcher("resultClass.jsp");
			rd.forward(request, response);
		}
	}

}
