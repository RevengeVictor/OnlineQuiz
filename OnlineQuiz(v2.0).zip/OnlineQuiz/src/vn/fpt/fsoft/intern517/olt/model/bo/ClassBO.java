package vn.fpt.fsoft.intern517.olt.model.bo;

import vn.fpt.fsoft.intern517.olt.model.dao.ClassDAO;

/**
 * ClassBO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 14, 2017        Nguyen Cong Huong          	Create
 */

public class ClassBO {
	ClassDAO classDAO = new ClassDAO();
	
	public String getClassName(String userName){
		return classDAO.getClassName(userName);
	}
}
