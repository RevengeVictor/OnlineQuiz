package vn.fpt.fsoft.intern517.olt.model.dao;

/**
 * ClassDAO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 14, 2017        Nguyen Cong Huong          	Create
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClassDAO extends BaseDAO {
	/*
	 * Ham tra ve ten ten lop theo username
	 */
	public String getClassName(String userName) {
		String sqlClassName = String
				.format("select cl.className from [STUDENT] st INNER JOIN [CLASS] as cl on cl.classID = st.classID where st.userName = '%s'",
						userName);
		ResultSet rs = null;
		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlClassName);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Lay ket qua truy van
		String className = null;
		try {
			while (rs.next()) {
				className = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return className;
	}
}
