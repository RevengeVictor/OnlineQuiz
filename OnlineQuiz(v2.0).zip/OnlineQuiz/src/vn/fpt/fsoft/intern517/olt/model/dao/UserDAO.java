package vn.fpt.fsoft.intern517.olt.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.User;

public class UserDAO extends BaseDAO {
	/*
	 * Ham kiem tra ten dang nhap va mat khau
	 */
	public boolean checkLogin(String userName, String password) {
		String sqlCheckLogin = "SELECT userName FROM [USER] WHERE userName = '"
				+ userName + "' AND password = '" + password + "'";
		ResultSet rs = null;
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlCheckLogin);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	/*
	 * Ham tra ve danh sach cac admin
	 */
	public ArrayList<User> getListAdmin(){
		String sqlListAdmin = "select userName from [USER] where type = 1";
		ResultSet rs = null;
		
		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListAdmin);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//Lay ket qua truy van
		ArrayList<User> listAdmin = new ArrayList<User>();
		User userAdmin;
		try {
			while(rs.next()){
				userAdmin = new User();
				userAdmin.setUserName(rs.getString(1));
				listAdmin.add(userAdmin);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listAdmin;
	}

}
