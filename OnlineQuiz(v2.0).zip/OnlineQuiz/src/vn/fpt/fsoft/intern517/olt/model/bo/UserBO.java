package vn.fpt.fsoft.intern517.olt.model.bo;
/**
 * UserBO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 14, 2017        Nguyen Cong Huong          	Create
 */
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.User;
import vn.fpt.fsoft.intern517.olt.model.dao.UserDAO;

public class UserBO {
	UserDAO userDAO = new UserDAO();
	
	public boolean checkLogin(String userName, String password){
		return userDAO.checkLogin(userName, password);
	}
	
	public ArrayList<User> getListAdmin(){
		return userDAO.getListAdmin();
	}
	
}

