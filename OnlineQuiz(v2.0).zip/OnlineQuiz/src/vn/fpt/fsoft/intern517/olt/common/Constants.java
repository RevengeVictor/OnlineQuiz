package vn.fpt.fsoft.intern517.olt.common;

/**
 * Utils.java
 *
 * Version 1.0
 *
 * Date: June 13, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 13, 2017        Nguyen Cong Huong          	Create
 */

public class Constants {
	public static final String LIBRARY_NAME = "net.sourceforge.jtds.jdbc.Driver";
	public static final String HOST_NAME = "localhost";
	public static final String SQL_INSTANCE_NAME = "MSSQLSERVER";
	public static final String DATABASE = "Online_Quiz";
	public static final String USERNAME = "sa";
	public static final String PASSWORD = "12345678";
	public static final String URL_CONNECTION = "jdbc:jtds:sqlserver://"
			+ HOST_NAME + ":1433/" + DATABASE + ";instance="
			+ SQL_INSTANCE_NAME;
}
