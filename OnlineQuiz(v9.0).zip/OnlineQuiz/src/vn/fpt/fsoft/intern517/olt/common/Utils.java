package vn.fpt.fsoft.intern517.olt.common;

/**
 * Utils.java
 * 
 * Version 1.0
 * 
 * Date: June 13, 2017
 * 
 * Copyright
 * 
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- June
 * 13, 2017 Nguyen Cong Huong Create
 */

public class Utils {
	/*
	 * Ham tra ve sau rong neu la null
	 */
	public static String getVaildString(String s) {
		if (s == null)
			return "";
		return s;
	}

	/*
	 * Ham tra ve: true = la so, false = la chuoi
	 */
	public static boolean checkNumber(String cloneNumber) {

		if (Character.isDigit(cloneNumber.charAt(0))) {
			return true;
		}
		return false;
	}

	/*
	 * Ham tra ve ten topic clone
	 */
	public static String newTopicName(String topicName, int cloneNumber) {
		String newTopicName = "";

		newTopicName = topicName.trim() + " (Thi lại lần " + (cloneNumber + 1)
				+ ")";

		return newTopicName;
	}
}
