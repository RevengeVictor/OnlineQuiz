package vn.fpt.fsoft.intern517.olt.model.dao;

/**
 * TopicDAO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 15, 2017        Nguyen Cong Huong          	Create
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.common.Utils;
import vn.fpt.fsoft.intern517.olt.model.bean.Topic;

public class TopicDAO extends BaseDAO {
	/*
	 * Tra ve mot danh sach: ma topic va ten topic va so lan clone
	 */
	public ArrayList<Topic> getListTopic() {
		String sqlListTopic = "select * from [TOPIC]";
		ResultSet rs = null;

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListTopic);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Lay ket qua truy van
		ArrayList<Topic> listTopic = new ArrayList<Topic>();
		Topic topic;
		try {
			while (rs.next()) {
				topic = new Topic();
				topic.setTopicID(rs.getInt(1));
				topic.setTopicName(rs.getString(2));
				topic.setCloneNumber(rs.getInt(3));
				listTopic.add(topic);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listTopic;
	}

	/*
	 * Xoa mot topic theo topicID
	 */
	public void deleteTopic(String topicID) {
		String sqlListTopic = "DELETE FROM [TOPIC] WHERE topicID = ?";

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListTopic);
			restmt.setInt(1, Integer.parseInt(topicID));
			restmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Ham lay so cloneNumber
	 */
	public int getCloneNumber(String topicID) {
		String sqlCloneNumber = "SELECT cloneNumber FROM [TOPIC] WHERE topicID = ?";
		ResultSet rs = null;

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlCloneNumber);
			restmt.setInt(1, Integer.parseInt(topicID));
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		int cloneNumber = 0;

		try {
			while (rs.next()) {
				cloneNumber = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cloneNumber;
	}

	/*
	 * Ham lay topicID theo topicName
	 */
	public int getTopicID(String topicName) {
		String sqlTopicName = "SELECT topicID FROM [TOPIC] WHERE topicName = ?";
		ResultSet rs = null;

		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlTopicName);
			restmt.setString(1, topicName);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		int topicID = 0;

		try {
			while (rs.next()) {
				topicID = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return topicID;
	}

	/*
	 * Ham them topic
	 */
	public void addTopic(String topicName, int cloneNumber) {
		String sqlNewTopic = "INSERT INTO [TOPIC](topicName, cloneNumber) VALUES (?,?)";

		// Ket noi va them du lieu trong database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection.prepareStatement(sqlNewTopic);
			restmt.setString(1, topicName);
			restmt.setInt(2, cloneNumber);
			restmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * Ham clone topic
	 */
	public void cloneTopic(String topicID, String topicName) {
		String sqlUdateCloneNumber = "UPDATE [TOPIC] SET cloneNumber = ? WHERE topicID = ?";
		String sqlCloneTopic = "INSERT INTO [QUIZ](quizName, topicID, answer, maxAnswer) SELECT q.quizName, t.topicID, q.answer, q.maxAnswer FROM [QUIZ] as q, [TOPIC] as t WHERE q.topicID = ? AND t.topicID = ?";
		PreparedStatement restmt = null;

		String newTopicName = Utils.newTopicName(topicName,
				getCloneNumber(topicID));

		try {
			Connection connection = getMyConnection();

			// Them topic moi
			addTopic(newTopicName, 0);

			// Uptate lai gia tri cloneNumber
			restmt = connection.prepareStatement(sqlUdateCloneNumber);
			restmt.setInt(1, getCloneNumber(topicID) + 1);
			restmt.setInt(2, Integer.parseInt(topicID));
			restmt.executeUpdate();

			// Clone
			restmt = connection.prepareStatement(sqlCloneTopic);
			restmt.setInt(1, Integer.parseInt(topicID));
			restmt.setInt(2, getTopicID(newTopicName));
			restmt.executeUpdate();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/*
	 * Ham kiem tra ten topic bi trung: true = trung ten, false = khong trung
	 * ten
	 */
	public boolean checkTopicName(String topicName) {
		String sqlCheckTopicName = "SELECT topicName FROM [TOPIC] WHERE topicName = ?";
		ResultSet rs = null;

		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlCheckTopicName);
			restmt.setString(1, topicName);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	/*
	 * Ham them dap an
	 */
	public void addAnswer(int quizName, String topicID, String answer,
			int maxAnswer) {
		String sqlAddAnswer = "INSERT INTO [QUIZ](quizName, topicID, answer, maxAnswer) VALUES (?,?,?,?)";

		// Ket noi va them du lieu trong database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection.prepareStatement(sqlAddAnswer);
			restmt.setInt(1, quizName);
			restmt.setInt(2, Integer.parseInt(topicID));
			restmt.setString(3, answer);
			restmt.setInt(4, maxAnswer);
			restmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
