package vn.fpt.fsoft.intern517.olt.model.bo;

/**
 * TopicBO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 15, 2017        Nguyen Cong Huong          	Create
 */

import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.Topic;
import vn.fpt.fsoft.intern517.olt.model.dao.TopicDAO;

public class TopicBO {
	TopicDAO topicDAO = new TopicDAO();

	public ArrayList<Topic> getListTopic() {
		return topicDAO.getListTopic();
	}

	public void deleteTopic(String topicID) {
		topicDAO.deleteTopic(topicID);
	}

	public void cloneTopic(String topicID, String topicName) {
		topicDAO.cloneTopic(topicID, topicName);
	}

	public boolean checkTopicName(String topicName) {
		return topicDAO.checkTopicName(topicName);
	}

	public int getTopicID(String topicName) {
		return topicDAO.getTopicID(topicName);
	}

	public void addTopic(String topicName, int cloneNumber) {
		topicDAO.addTopic(topicName, cloneNumber);
	}

	public void addAnswer(int quizName, String topicID, String answer,
			int maxAnswer) {
		topicDAO.addAnswer(quizName, topicID, answer, maxAnswer);
	}

}
