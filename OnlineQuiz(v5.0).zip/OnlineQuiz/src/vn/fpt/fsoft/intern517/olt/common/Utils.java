package vn.fpt.fsoft.intern517.olt.common;

/**
 * Utils.java
 * 
 * Version 1.0
 * 
 * Date: June 13, 2017
 * 
 * Copyright
 * 
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- June
 * 13, 2017 Nguyen Cong Huong Create
 */

public class Utils {
	/**
	 * Ham tra ve gioi tinh: 1=Nam, 0=Nu
	 * 
	 * @param val
	 * @return String
	 */
	public static String gender(String sex) {
		if ("0".equals(sex)) {
			return "Nữ";
		}
		return "Nam";
	}

	/*
	 * Ham tra ve: true = hai chuoi giong nhau, false = hai chuoi khac nhau
	 */
	public static boolean checkPassword(String password, String checkPassword) {
		if (password.equals(checkPassword)) {
			return true;
		} else
			return false;
	}
}
