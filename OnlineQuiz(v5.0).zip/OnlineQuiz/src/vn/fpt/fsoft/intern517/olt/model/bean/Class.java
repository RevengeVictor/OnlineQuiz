package vn.fpt.fsoft.intern517.olt.model.bean;

/**
 * AddAdminServlet.java
 * 
 * Copyright
 * 
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- June
 * 20, 2017 Nguyen Cong Huong Create
 */

public class Class {
	private int classID;
	private String className;

	public int getClassID() {
		return classID;
	}

	public void setClassID(int classID) {
		this.classID = classID;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

}
