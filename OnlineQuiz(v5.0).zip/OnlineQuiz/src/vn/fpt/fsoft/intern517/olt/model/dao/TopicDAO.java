package vn.fpt.fsoft.intern517.olt.model.dao;
/**
 * TopicDAO.java
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          			DESCRIPTION
 * -----------------------------------------------------------------------
 * June 15, 2017        Nguyen Cong Huong          	Create
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.fpt.fsoft.intern517.olt.model.bean.Topic;

public class TopicDAO extends BaseDAO{
	/*
	 * Tra ve mot danh sach: ma topic va ten topic
	 */
	public ArrayList<Topic> getListTopic() {
		String sqlListTopic = "select topicID, topicName from [TOPIC]";
		ResultSet rs = null;
		// Ket noi va truy van database
		try {
			Connection connection = getMyConnection();
			PreparedStatement restmt = connection
					.prepareStatement(sqlListTopic);
			rs = restmt.executeQuery();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Lay ket qua truy van
		ArrayList<Topic> listTopic = new ArrayList<Topic>();
		Topic topic;
		try {
			while(rs.next()){
				topic = new Topic();
				topic.setTopicID(rs.getInt(1));
				topic.setTopicName(rs.getString(2));
				listTopic.add(topic);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listTopic;
	}
}
